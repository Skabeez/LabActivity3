import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

export default function App() {
  const [anime, setAnime] = useState("");
  const [list, setList] = useState([]);

  const addAnime = () => {
    if (anime.trim() === "") return;
    setList([...list, anime]);
    setAnime("");
  };

  return (
    <LinearGradient
      colors={["#f9f4ff", "#f8e6ff", "#f9f4ff"]}
      style={styles.container}
    >
      <Text style={styles.header}>🌸 My Anime List 🌸</Text>

      {/* Input Section */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter Anime"
          placeholderTextColor="#b08dc0"
          value={anime}
          onChangeText={setAnime}
        />
        <TouchableOpacity onPress={addAnime}>
          <LinearGradient
            colors={["#fcb1e0", "#b38bfa"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.addButton}
          >
            <Text style={styles.addButtonText}>+ Add</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Anime List */}
      <FlatList
        data={list}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardText}>{item}</Text>
          </View>
        )}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 80,
    paddingHorizontal: 25,
    alignItems: "center",
  },
  header: {
    fontSize: 32,
    color: "#8057b8",
    fontWeight: "900",
    marginBottom: 25,
    letterSpacing: 1,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 25,
  },
  input: {
    flex: 1,
    height: 50,
    borderColor: "#b38bfa",
    borderWidth: 1.5,
    borderRadius: 15,
    paddingHorizontal: 15,
    color: "#4a3f70",
    backgroundColor: "#fff",
    fontSize: 16,
  },
  addButton: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginLeft: 10,
  },
  addButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  card: {
    width: "100%",
    padding: 15,
    borderRadius: 15,
    marginVertical: 8,
    borderColor: "#dec7ff",
    borderWidth: 1,
    backgroundColor: "#ffffff",
  },
  cardText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#5b4b7a",
  },
});

